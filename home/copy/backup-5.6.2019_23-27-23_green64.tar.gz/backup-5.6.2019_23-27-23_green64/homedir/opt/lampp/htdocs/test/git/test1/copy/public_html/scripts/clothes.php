<?php
require 'htmlexample.php';
?>