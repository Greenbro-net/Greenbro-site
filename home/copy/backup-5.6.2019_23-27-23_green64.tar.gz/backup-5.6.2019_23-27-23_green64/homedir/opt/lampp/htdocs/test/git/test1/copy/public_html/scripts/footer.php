<footer class="footer" id="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 footer__link">
                <a href="#catalog">Наверх</a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 footer__descr">
						<span>
							&copy; 2019, Greenbro
						    All trademarks and registered trademarks appearing on 
						    this site are the property of their respective owners.
						</span>
            </div>
        </div>
    </div>
</footer>