<!DOCTYPE html>
<html lang="ru">
<head>
    
    <title>Greenbro</title>
    <link rel="stylesheet" type="text/css" media="screen" href="../cssgb.css" />
</head>


<body>

 <div id="main">
<img id="logo"  src="../images/logo1.jpg" alt="It is our logotype" title="logo">

 <p id="slogan1">All things what you need.. </p>
 <br />
 <p id="slogan2"> and other healthy, tasty things... </p>

</div>




<div id="leftcolumn"> </div>
<div id="rightcolumn">  </div>



 <br />
 <div id ="back_home">
<a   href="../index.php">back home</a>
 </div>
<?php
    require "footer.php";
   
   ?> 
    
</body>
   
   
</html>