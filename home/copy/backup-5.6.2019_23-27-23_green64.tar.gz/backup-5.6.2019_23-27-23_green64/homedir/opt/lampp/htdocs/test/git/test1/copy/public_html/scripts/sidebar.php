	<ul id="menu">
	    <li><a href="foods.php">Продукти</a></li>
	    <li><a href="clothes.php">Одяг</a></li>    
	    <li><a href="goods.php">Речі</a></li>
	    <li><a href="books.php">Література</a></li>
	    <li><a href="recipe.php">Рецепти</a></li>
	    <li><a href="other.php"> Інше</a></li>
	</ul>