
 <!-- <!DOCTYPE html>
<html>
<head> -->
<?php

?>
    <!-- <title>Greenbro</title>
    <link rel="stylesheet" type="text/css" media="screen" href="cssgb.css" />
</head>
<body>  -->



<div id="footer">
      &copy; 2019, Greenbro
<p>
      All trademarks and registered trademarks appearing on 
      this site are the property of their respective owners.
</p>
    </div>
 <!-- </body> 
</html>  -->