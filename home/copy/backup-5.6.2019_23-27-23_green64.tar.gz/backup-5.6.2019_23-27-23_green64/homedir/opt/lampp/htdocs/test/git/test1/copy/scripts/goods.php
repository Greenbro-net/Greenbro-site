<?php
require 'htmlexample_goods.php';