-- MySQL dump 10.16  Distrib 10.2.23-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: green64_products
-- ------------------------------------------------------
-- Server version	10.2.21-MariaDB-10.2.21+maria~trusty

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `brand` varchar(255) CHARACTER SET cp1251 NOT NULL,
  `brand_id` int(11) NOT NULL,
  `mini_description` text CHARACTER SET cp1251 NOT NULL,
  `description` text CHARACTER SET cp1251 NOT NULL,
  `image` text CHARACTER SET cp1251 NOT NULL,
  `price` double NOT NULL,
  `sale` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `visible` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`id`, `name`, `brand`, `brand_id`, `mini_description`, `description`, `image`, `price`, `sale`, `quantity`, `datetime`, `visible`) VALUES (1,'Первое Test','Test-brand',123,'Hello','Full text description','flour.jpg',9.99,10,22,'2019-04-08 11:00:06',1),(2,'next','next',234,'','Lorem ipsum dolor sit amet, consectetur adipiscing...','oil.jpg',11.99,0,28,'2019-04-09 18:19:30',1),(3,'test','test',11,'test','test','oil.jpg',10,0,21,'2019-04-11 09:01:57',1),(4,'next','next',234,'','Lorem ipsum dolor sit amet, consectetur adipiscing...','oil.jpg',11.99,0,23,'2019-04-09 18:19:30',1),(5,'Test Descr','Test Descr',123,'mini_descr','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sed rutrum tortor, at iaculis magna. Proin sollicitudin elit sed efficitur malesuada. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Vivamus dignissim convallis tempus. Etiam vehicula aliquet justo, euismod pharetra velit congue tincidunt. Fusce cursus commodo leo ','flour.jpg',12.45,0,19,'2019-04-08 11:00:06',1);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'green64_products'
--

--
-- Dumping routines for database 'green64_products'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-06 23:27:27
